<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>XtraSkool</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
</body>
</html>
<div class="background" style="background-color: #2d1708;"> s</div>
<div class="background" style="background-color: #8CC63F;" >s</div>
<div class="login">
 <img src="image/logo.PNG" alt="logo" style="width:150px; height:150px; margin:20px 0px 0px 120px;">
 <h3>Login to your account</h3>
 <h4>Enter your credentials</h4>
 <input type="text" placeholder="Username">
 <input type="text" placeholder="Password">
 <form action="dashboard.php">
    <button type="submit" >Log in</button>
 </form>


</div>